import './App.css';
import CardGame from './components/jsx/CardGame';

function App() {
  return (
    <div className="App">
      <CardGame />
    </div>
  );
}

export default App;
