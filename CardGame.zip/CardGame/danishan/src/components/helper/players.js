export const playerCode = Array.from({ length: 50 }, (_, i) => String(i + 1).padStart(2, '0'));
